create database harsh;
use harsh;
create table cnc(id int not null primary key auto_increment, file longblob, f_name varchar(120), f_date varchar(120));
select * from cnc;
drop table cnc



